# Roadmap

- [x] Fix hero photo not loading (moved to public/ahnaf-portrait.png)
- [x] Lighten hero overlay so the photo is clearer
