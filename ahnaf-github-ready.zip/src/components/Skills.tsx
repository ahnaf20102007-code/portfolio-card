import { motion } from 'framer-motion'

const skills = [
  {
    title: 'Web Development',
    description: 'Building modern, creative and interactive websites.',
  },
  {
    title: 'Gaming',
    description: 'A gamer with competitive energy and a passion for virtual worlds.',
  },
  {
    title: 'Grand Theft Auto VI',
    description: 'Waiting for the next level of open-world chaos.',
  },
  {
    title: 'Mathematical Problem Solving',
    description: 'Breaking down complex problems with logic and creativity.',
  },
]

const fadeInUp = {
  initial: { opacity: 0, y: 40 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-100px' },
  transition: { duration: 0.8, ease: 'easeOut' }
}

export function Skills() {
  return (
    <section id="skills" className="section-padding bg-[#0d0d0d]">
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <motion.div {...fadeInUp} className="mb-16">
          <span className="text-sm text-gray-500 tracking-widest uppercase">My Skills & Interests</span>
          <div className="w-6 h-px bg-gray-600 mt-2" />
        </motion.div>

        <motion.h2
          {...fadeInUp}
          className="font-display text-[10vw] lg:text-section leading-none tracking-tight mb-12 lg:mb-20"
        >
          SKILLS
        </motion.h2>

        {/* Skills List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-8 lg:gap-y-12">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.title}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="border-b border-gray-800 pb-6"
            >
              <h3 className="text-lg md:text-xl lg:text-2xl text-white font-light mb-2">
                {skill.title}
              </h3>
              <p className="text-sm lg:text-base text-gray-500">
                {skill.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Tagline */}
        <motion.p
          {...fadeInUp}
          className="mt-16 lg:mt-24 text-base lg:text-lg text-gray-400 italic"
        >
          "I code, I game, I solve problems, and occasionally question my own sanity."
        </motion.p>
      </div>
    </section>
  )
}
