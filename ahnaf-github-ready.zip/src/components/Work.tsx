import { motion } from 'framer-motion'

const experiences = [
  {
    title: 'Website Development',
    description: 'Created server-related websites and functional web experiences.',
  },
  {
    title: 'Video Editing',
    description: 'Edited videos with creative storytelling, smooth transitions, and engaging visuals.',
  },
  {
    title: 'Graphic Design',
    description: 'Designed creative graphics, digital assets, and visual content.',
  },
  {
    title: 'Content Creation',
    description: 'Developed engaging content with a focus on creativity, presentation, and audience engagement.',
  },
]

const fadeInUp = {
  initial: { opacity: 0, y: 60 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-100px' },
  transition: { duration: 1, ease: 'easeOut' }
}

export function Work() {
  return (
    <section id="work" className="section-padding">
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <motion.div {...fadeInUp} className="mb-16">
          <span className="text-sm text-gray-500 tracking-widest uppercase">Work Experience & Projects</span>
          <div className="w-6 h-px bg-gray-600 mt-2" />
        </motion.div>

        <motion.h2
          {...fadeInUp}
          className="font-display text-[10vw] lg:text-section leading-none tracking-tight mb-12 lg:mb-16"
        >
          WORK
        </motion.h2>

        {/* Intro */}
        <motion.p
          {...fadeInUp}
          className="text-base lg:text-lg text-gray-300 leading-relaxed max-w-2xl mb-16 lg:mb-24"
        >
          I've explored multiple creative and technical fields, gaining hands-on 
          experience through personal projects and independent work.
        </motion.p>

        {/* Experiences */}
        <div className="space-y-0">
          {experiences.map((exp, index) => (
            <motion.article
              key={exp.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.8, ease: 'easeOut', delay: index * 0.1 }}
              className="border-t border-gray-800 py-8 md:py-12 group hover:bg-gray-900/30 transition-colors px-4 -mx-4"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-8">
                <div className="lg:col-span-5">
                  <h3 className="text-xl md:text-2xl lg:text-3xl font-light text-white">
                    {exp.title}
                  </h3>
                </div>
                <div className="lg:col-span-7">
                  <p className="text-gray-400 leading-relaxed text-sm lg:text-base">
                    {exp.description}
                  </p>
                </div>
              </div>
            </motion.article>
          ))}
          <div className="border-t border-gray-800" />
        </div>

        {/* Closing */}
        <motion.div {...fadeInUp} className="mt-16 lg:mt-24 max-w-2xl">
          <p className="text-base lg:text-lg text-gray-300 leading-relaxed mb-6">
            I'm always exploring new skills, taking on challenges, and turning 
            ideas into something real. My experience comes from learning by 
            doing, experimenting, and creating.
          </p>
          <p className="text-base lg:text-lg text-gray-400 italic">
            "Not limited to one skill — I create, design, edit, develop, and keep evolving."
          </p>
        </motion.div>
      </div>
    </section>
  )
}
