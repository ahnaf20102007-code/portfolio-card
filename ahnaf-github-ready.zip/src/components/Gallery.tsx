import { motion } from 'framer-motion'

const photos = [
  { src: `${import.meta.env.BASE_URL}gallery-blueflower.jpg`, alt: 'Blue flower after rain', caption: 'AFTER THE RAIN', wide: false },
  { src: `${import.meta.env.BASE_URL}gallery-ginger.jpg`, alt: 'Ginger the cat', caption: 'GINGER', wide: false },
  { src: `${import.meta.env.BASE_URL}gallery-sunset.jpg`, alt: 'Palm trees at sunset', caption: 'GOLDEN HOUR', wide: true },
  { src: `${import.meta.env.BASE_URL}gallery-mirror.jpg`, alt: 'Auto-rickshaw mirror', caption: 'SIDE VIEW', wide: false },
  { src: `${import.meta.env.BASE_URL}gallery-disco.jpg`, alt: 'Disco ball in colored light', caption: 'DISCO LIGHTS', wide: false },
  { src: `${import.meta.env.BASE_URL}gallery-graffiti.jpg`, alt: 'Street graffiti art', caption: 'STREET ART', wide: true },
  { src: `${import.meta.env.BASE_URL}gallery-fire.jpg`, alt: 'Burning cart and smoke', caption: 'EMBERS', wide: false },
  { src: `${import.meta.env.BASE_URL}gallery-cameras.jpg`, alt: 'Vintage camera collection', caption: 'VINTAGE GEAR', wide: false },
  { src: `${import.meta.env.BASE_URL}gallery-bougainvillea.jpg`, alt: 'Bougainvillea over a Dhaka sidewalk', caption: 'PINK CANOPY', wide: false },
  { src: `${import.meta.env.BASE_URL}gallery-plate.jpg`, alt: 'Fried fish and rice in a red bowl with warm bokeh', caption: 'THE PLATE', wide: false },
  { src: `${import.meta.env.BASE_URL}gallery-lowtide.jpg`, alt: 'Sea foam and seaweed at sunset', caption: 'LOW TIDE', wide: true },
  { src: `${import.meta.env.BASE_URL}gallery-gta6.jpg`, alt: 'Grand Theft Auto VI Ultimate Edition artwork', caption: 'GTA VI — ULTIMATE EDITION', wide: true },
]

const fadeInUp = {
  initial: { opacity: 0, y: 40 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-100px' },
  transition: { duration: 0.8, ease: 'easeOut' }
}

export function Gallery() {
  return (
    <section id="gallery" className="section-padding bg-[#0d0d0d]">
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <motion.div {...fadeInUp} className="mb-16">
          <span className="text-sm text-gray-500 tracking-widest uppercase">Through My Lens</span>
          <div className="w-6 h-px bg-gray-600 mt-2" />
        </motion.div>

        <motion.h2
          {...fadeInUp}
          className="font-display text-[10vw] lg:text-section leading-none tracking-tight mb-12 lg:mb-20"
        >
          GALLERY
        </motion.h2>

        {/* Photo Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {photos.map((photo, index) => (
            <motion.figure
              key={photo.src}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.7, delay: (index % 2) * 0.15 }}
              className={photo.wide ? 'md:col-span-2' : ''}
            >
              <div className="overflow-hidden">
                <img
                  src={photo.src}
                  alt={photo.alt}
                  loading="lazy"
                  className={`w-full object-cover grayscale hover:grayscale-0 hover:scale-105 transition-all duration-700 ${
                    photo.wide ? 'h-64 md:h-96' : 'h-96 md:h-[32rem]'
                  }`}
                />
              </div>
              <figcaption className="mt-3 text-xs text-gray-500 tracking-widest uppercase">
                {photo.caption}
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  )
}
